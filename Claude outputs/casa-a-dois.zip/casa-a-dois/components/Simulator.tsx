"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import NumField from "./NumField";
import {
  CHECKS,
  DEFAULTS,
  GROUPS,
  LEFT_COLOR,
  RENT_COLOR,
  SECTIONS,
  clamp,
  compute,
  euro,
  pct,
  type Mode,
  type Values,
} from "@/lib/model";

const KEY = "casa-aveiro-v3";

type Saved = { values: Values; mode: Mode; checked: boolean[] };

export default function Simulator() {
  const [values, setValues] = useState<Values>(DEFAULTS);
  const [mode, setMode] = useState<Mode>("proportional");
  const [checked, setChecked] = useState<boolean[]>(() => CHECKS.map(() => false));
  const [active, setActive] = useState("s1");
  const [ready, setReady] = useState(false);

  /* ---------- load once on the client ---------- */
  useEffect(() => {
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) {
        const saved = JSON.parse(raw) as Partial<Saved>;
        if (saved.values) {
          setValues({
            ...DEFAULTS,
            ...saved.values,
            expenses: { ...DEFAULTS.expenses, ...(saved.values.expenses || {}) },
          });
        }
        if (saved.mode === "equal" || saved.mode === "proportional") setMode(saved.mode);
        if (Array.isArray(saved.checked)) {
          setChecked(CHECKS.map((_, i) => !!saved.checked![i]));
        }
      }
    } catch {
      /* storage unavailable or corrupt — carry on with defaults */
    }
    setReady(true);
  }, []);

  /* ---------- persist ---------- */
  useEffect(() => {
    if (!ready) return;
    try {
      localStorage.setItem(KEY, JSON.stringify({ values, mode, checked }));
    } catch {
      /* ignore quota / private mode */
    }
  }, [values, mode, checked, ready]);

  /* ---------- scroll spy ---------- */
  useEffect(() => {
    const obs = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) setActive(e.target.id);
        });
      },
      { rootMargin: "-20% 0px -65% 0px" }
    );
    document.querySelectorAll(".sec").forEach((s) => obs.observe(s));
    return () => obs.disconnect();
  }, []);

  const set = useCallback(<K extends keyof Values>(key: K, v: Values[K]) => {
    setValues((prev) => ({ ...prev, [key]: v }));
  }, []);

  const setExpense = useCallback((id: string, v: number) => {
    setValues((prev) => ({ ...prev, expenses: { ...prev.expenses, [id]: v } }));
  }, []);

  const reset = () => {
    setValues(DEFAULTS);
    setMode("proportional");
    setChecked(CHECKS.map(() => false));
  };

  const c = useMemo(() => compute(values, mode), [values, mode]);
  const done = checked.filter(Boolean).length;

  const stackParts: [string, number][] = [
    [RENT_COLOR, values.rent],
    ...GROUPS.map((g) => [g.color, c.groupSums[g.id]] as [string, number]),
    [LEFT_COLOR, Math.max(0, c.left)],
  ];
  const base = c.income > 0 ? c.income : 1;

  const rentBarClass =
    "fill" + (c.rentShare > 0.4 ? " bad" : c.rentShare > 0.3 ? " warn" : "");
  const saveBarClass = "fill" + (c.rate < 0 ? " bad" : c.rate < 0.1 ? " warn" : "");

  const goalMonths = values.goal > 0 && c.perMonth > 0 ? values.goal / c.perMonth : 0;

  return (
    <div className="shell">
      {/* ============ NAV ============ */}
      <nav className="sidenav" aria-label="Índice">
        <div className="navcard">
          <div className="navtitle">Índice</div>
          {SECTIONS.map((s) => (
            <a key={s.id} href={`#${s.id}`} className={active === s.id ? "on" : undefined}>
              <i>{s.n}</i>
              {s.label}
            </a>
          ))}
        </div>
        <div className="navfoot">
          <button className="btn" onClick={() => window.print()}>
            ⎙ Imprimir / PDF
          </button>
          <button className="btn ghost" onClick={reset}>
            ↺ Repor valores
          </button>
          <div className="saved">Guardado automaticamente neste dispositivo</div>
        </div>
      </nav>

      {/* ============ CONTENT ============ */}
      <div>
        {/* KPI rail */}
        <section className="kpis" aria-label="Resumo financeiro">
          <div className="kpi">
            <small>Entra / mês</small>
            <div className="v num">{euro(c.income)}</div>
            <div className="s">Mês normal, sem extras</div>
          </div>
          <div className="kpi">
            <small>Sai / mês</small>
            <div className="v num">{euro(c.total)}</div>
            <div className="s">Casa + vida</div>
          </div>
          <div className="kpi">
            <small>Sobra / mês</small>
            <div className={"v num " + (c.left >= 0 ? "green" : "red")}>{euro(c.left)}</div>
            <div className="s">{c.income > 0 ? `${pct(c.rate)} do que entra` : "—"}</div>
          </div>
          <div className="kpi">
            <small>Poupança / ano</small>
            <div className={"v num " + (c.annual >= 0 ? "gold" : "red")}>{euro(c.annual)}</div>
            <div className="s">Inclui subsídios</div>
          </div>
        </section>

        {/* 01 */}
        <section className="sec" id="s1">
          <div className="sechead">
            <div className="badge">01</div>
            <h2>Rendimentos</h2>
          </div>
          <div className="secbody">
            <p className="hint">
              Valores <strong>líquidos</strong> que recebem efetivamente por pagamento. Os meses
              extra entram só nos cálculos anuais.
            </p>
            <div className="grid2">
              <div className="box">
                <label htmlFor="mine">O meu líquido / pagamento</label>
                <NumField
                  id="mine"
                  value={values.mine}
                  onChange={(v) => set("mine", v)}
                  max={20000}
                  step={50}
                />
                <div className="sublabel">
                  Software ·{" "}
                  <NumField
                    className="num-in sm"
                    value={values.mineN}
                    onChange={(v) => set("mineN", clamp(v, 12, 14))}
                    min={12}
                    max={14}
                    aria-label="Pagamentos por ano (eu)"
                  />{" "}
                  pagamentos/ano
                </div>
              </div>
              <div className="box">
                <label htmlFor="hers">O líquido dela / pagamento</label>
                <NumField
                  id="hers"
                  value={values.hers}
                  onChange={(v) => set("hers", v)}
                  max={20000}
                  step={50}
                />
                <div className="sublabel">
                  Civil ·{" "}
                  <NumField
                    className="num-in sm"
                    value={values.hersN}
                    onChange={(v) => set("hersN", clamp(v, 12, 14))}
                    min={12}
                    max={14}
                    aria-label="Pagamentos por ano (ela)"
                  />{" "}
                  pagamentos/ano
                </div>
              </div>
            </div>
            <div className="callout">
              Entra <b className="num">{euro(c.income)}</b> num mês normal e{" "}
              <b className="num">{euro(c.yearIncome)}</b> ao longo do ano.
            </div>
          </div>
        </section>

        {/* 02 */}
        <section className="sec" id="s2">
          <div className="sechead">
            <div className="badge">02</div>
            <h2>Despesas mensais</h2>
            <span className="tag num">{euro(c.total)} / mês</span>
          </div>
          <div className="secbody">
            <p className="hint">
              Cinco categorias, cada uma com o seu subtotal e peso no total. A renda está no topo,
              com cursor para explorar.
            </p>

            <div className="box" style={{ marginBottom: "var(--s4)" }}>
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "space-between",
                  gap: "var(--s3)",
                }}
              >
                <label htmlFor="rentNum" className="boxlabel" style={{ margin: 0 }}>
                  Renda mensal do T1
                </label>
                <NumField
                  id="rentNum"
                  style={{ width: 116 }}
                  value={values.rent}
                  onChange={(v) => set("rent", v)}
                  max={5000}
                  step={25}
                />
              </div>
              <input
                type="range"
                min={400}
                max={1500}
                step={25}
                value={clamp(values.rent, 400, 1500)}
                onChange={(e) => set("rent", Number(e.target.value))}
                aria-label="Renda mensal"
              />
              <div className="ends">
                <span>400 €</span>
                <span>950 €</span>
                <span>1 500 €</span>
              </div>
              <div className="note" style={{ marginTop: "var(--s3)" }}>
                Objetivo interessante: <strong>750–850 €</strong>. Acima de{" "}
                <strong>900–1 000 €</strong>, vale a pena comparar também T2. Intervalos
                orientativos, não uma cotação atual.
              </div>
            </div>

            {GROUPS.map((g) => (
              <div className="group" key={g.id}>
                <div className="grouphead">
                  <i className="swatch" style={{ background: g.color }} />
                  <h3>{g.name}</h3>
                  <span className="sub num">{euro(c.groupSums[g.id])}</span>
                  <span className="shareof">
                    {c.total > 0 ? Math.round((c.groupSums[g.id] / c.total) * 100) + "%" : "—"}
                  </span>
                </div>
                <div className="rows">
                  {g.items.map((it) => (
                    <div className="erow" key={it.id}>
                      <label htmlFor={it.id}>{it.label}</label>
                      <span className="pc">
                        {c.total > 0
                          ? Math.round(((values.expenses[it.id] || 0) / c.total) * 100) + "%"
                          : "—"}
                      </span>
                      <NumField
                        id={it.id}
                        value={values.expenses[it.id] ?? 0}
                        onChange={(v) => setExpense(it.id, v)}
                        max={10000}
                        step={5}
                      />
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* 03 */}
        <section className="sec" id="s3">
          <div className="sechead">
            <div className="badge">03</div>
            <h2>Orçamento do mês</h2>
            <span
              className="tag"
              style={{
                color: c.health.color,
                borderColor: c.health.color,
                background: "transparent",
              }}
            >
              {c.health.label}
            </span>
          </div>
          <div className="secbody">
            <p className="hint">O que entra, o que sai e o que sobra num mês normal.</p>
            <div className="bigrow">
              <div>
                <div className="boxlabel">Sobra todos os meses</div>
                <div className={"total num " + (c.left >= 0 ? "green" : "red")}>{euro(c.left)}</div>
              </div>
              <div style={{ textAlign: "right" }}>
                <div className="boxlabel">Despesa total</div>
                <div className="num" style={{ fontSize: 22, fontWeight: 750 }}>
                  {euro(c.total)}
                </div>
              </div>
            </div>
            <div className="stack" role="img" aria-label="Distribuição dos rendimentos">
              {stackParts.map(([color, v], i) => (
                <div
                  key={i}
                  style={{ background: color, width: `${clamp((v / base) * 100, 0, 100)}%` }}
                />
              ))}
            </div>
            <div className="key">
              {[
                ["Renda", RENT_COLOR] as const,
                ...GROUPS.map((g) => [g.name, g.color] as const),
                ["Sobra", LEFT_COLOR] as const,
              ].map(([n, col]) => (
                <span key={n}>
                  <i style={{ background: col }} />
                  {n}
                </span>
              ))}
            </div>

            <div className="meter">
              <div className="meterhead">
                <span>Peso da renda nos salários normais</span>
                <b>{c.income > 0 ? pct(c.rentShare) : "—"}</b>
              </div>
              <div className="track">
                <div
                  className={rentBarClass}
                  style={{ width: `${clamp(c.rentShare * 100, 0, 100)}%` }}
                />
              </div>
              <div className="ends" style={{ marginTop: 5 }}>
                <span>confortável &lt; 30%</span>
                <span>apertado &gt; 40%</span>
              </div>
            </div>

            <div className="meter">
              <div className="meterhead">
                <span>Taxa de poupança</span>
                <b>{c.income > 0 ? pct(c.rate) : "—"}</b>
              </div>
              <div className="track">
                <div className={saveBarClass} style={{ width: `${clamp(c.rate * 100, 0, 100)}%` }} />
              </div>
              <div className="ends" style={{ marginTop: 5 }}>
                <span>mínimo 10%</span>
                <span>ótimo &gt; 25%</span>
              </div>
            </div>
          </div>
        </section>

        <div className="cols">
          {/* 04 */}
          <section className="sec" id="s4">
            <div className="sechead">
              <div className="badge">04</div>
              <h2>Divisão dos custos</h2>
            </div>
            <div className="secbody">
              <p className="hint">Metade cada um, ou na proporção dos salários.</p>
              <div className="toggle" role="group" aria-label="Método de divisão">
                <button
                  aria-pressed={mode === "proportional"}
                  onClick={() => setMode("proportional")}
                >
                  Proporcional
                </button>
                <button aria-pressed={mode === "equal"} onClick={() => setMode("equal")}>
                  50 / 50
                </button>
              </div>
              <ul className="list">
                <li>
                  <span>Eu pago / mês</span>
                  <b className="num">{euro(c.mineShare)}</b>
                </li>
                <li>
                  <span>Fico com</span>
                  <b className={"num " + (values.mine - c.mineShare >= 0 ? "green" : "red")}>
                    {euro(values.mine - c.mineShare)}
                  </b>
                </li>
                <li className="emph" style={{ borderTop: 0, marginTop: 0 }}>
                  <span>Ela paga / mês</span>
                  <b className="num">{euro(c.herShare)}</b>
                </li>
                <li>
                  <span>Fica com</span>
                  <b className={"num " + (values.hers - c.herShare >= 0 ? "green" : "red")}>
                    {euro(values.hers - c.herShare)}
                  </b>
                </li>
              </ul>
              <div className="callout">
                O simulador assume que <strong>todas as despesas inseridas são partilhadas</strong>.
                Gastos pessoais podem ficar fora da conta conjunta.
              </div>
            </div>
          </section>

          {/* 05 */}
          <section className="sec" id="s5">
            <div className="sechead">
              <div className="badge">05</div>
              <h2>Poupança anual</h2>
            </div>
            <div className="secbody">
              <p className="hint">Projeção a 12 meses, com subsídios incluídos.</p>
              <ul className="list">
                <li>
                  <span>Rendimento líquido anual</span>
                  <b className="num">{euro(c.yearIncome)}</b>
                </li>
                <li>
                  <span>Despesas anuais (12 meses)</span>
                  <b className="num">{euro(c.total * 12)}</b>
                </li>
                <li className="emph">
                  <span>Saldo anual projetado</span>
                  <b className={"num " + (c.annual >= 0 ? "green" : "red")}>{euro(c.annual)}</b>
                </li>
                <li>
                  <span>Média mensal anualizada</span>
                  <b className="num">{euro(c.perMonth)}</b>
                </li>
              </ul>
              <div className="box" style={{ marginTop: "var(--s4)" }}>
                <label htmlFor="goal">Objetivo de poupança (€)</label>
                <NumField
                  id="goal"
                  value={values.goal}
                  onChange={(v) => set("goal", v)}
                  max={500000}
                  step={500}
                />
                <div className="meter" style={{ marginTop: "var(--s3)" }}>
                  <div className="meterhead">
                    <span>
                      {values.goal <= 0
                        ? "Define um objetivo"
                        : c.perMonth <= 0
                          ? "Sem margem para poupar"
                          : goalMonths <= 12
                            ? `Atingido em ${Math.ceil(goalMonths)} meses`
                            : `Atingido em ${(goalMonths / 12).toFixed(1).replace(".", ",")} anos`}
                    </span>
                    <b>
                      {values.goal > 0 && c.perMonth > 0 ? `${euro(c.perMonth)} / mês` : "—"}
                    </b>
                  </div>
                  <div className="track">
                    <div
                      className={"fill" + (values.goal > 0 && c.perMonth <= 0 ? " bad" : "")}
                      style={{
                        width:
                          values.goal > 0 && c.perMonth > 0
                            ? `${clamp((c.annual / values.goal) * 100, 0, 100)}%`
                            : "0%",
                      }}
                    />
                  </div>
                </div>
              </div>
              <div className="callout">
                A média anualizada inclui férias/Natal. Para pagar contas, usem sempre o{" "}
                <strong>mês normal</strong>.
              </div>
            </div>
          </section>
        </div>

        {/* 06 */}
        <section className="sec" id="s6">
          <div className="sechead">
            <div className="badge">06</div>
            <h2>Comparar rendas</h2>
          </div>
          <div className="secbody">
            <p className="hint">Mantendo tudo o resto igual, o que muda com cada renda.</p>
            <table>
              <thead>
                <tr>
                  <th>Renda</th>
                  <th>Sobra / mês</th>
                  <th>Poupança / ano</th>
                  <th>% do salário</th>
                </tr>
              </thead>
              <tbody>
                {c.scenarios.map((s) => (
                  <tr key={s.rent} className={s.current ? "here" : undefined}>
                    <td>{euro(s.rent)}</td>
                    <td style={{ color: s.left < 0 ? "var(--red)" : "var(--green)" }}>
                      {euro(s.left)}
                    </td>
                    <td style={{ color: s.annual < 0 ? "var(--red)" : "var(--gold)" }}>
                      {euro(s.annual)}
                    </td>
                    <td
                      style={{
                        color:
                          s.share > 0.4
                            ? "var(--red)"
                            : s.share > 0.3
                              ? "var(--gold)"
                              : "var(--muted)",
                      }}
                    >
                      {c.income > 0 ? pct(s.share) : "—"}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        <div className="cols">
          {/* 07 */}
          <section className="sec" id="s7">
            <div className="sechead">
              <div className="badge">07</div>
              <h2>Custo de entrada</h2>
            </div>
            <div className="secbody">
              <p className="hint">O dinheiro inicial para arrendar e instalar-se.</p>
              <div className="grid2">
                <div className="box">
                  <label htmlFor="depositN">Meses de caução</label>
                  <NumField
                    id="depositN"
                    value={values.depositN}
                    onChange={(v) => set("depositN", clamp(v, 0, 3))}
                    max={3}
                  />
                </div>
                <div className="box">
                  <label htmlFor="advanceN">Rendas adiantadas (extra)</label>
                  <NumField
                    id="advanceN"
                    value={values.advanceN}
                    onChange={(v) => set("advanceN", clamp(v, 0, 3))}
                    max={3}
                  />
                </div>
                <div className="box">
                  <label htmlFor="furniture">Móveis e equipamento</label>
                  <NumField
                    id="furniture"
                    value={values.furniture}
                    onChange={(v) => set("furniture", v)}
                    max={30000}
                    step={50}
                  />
                </div>
                <div className="box">
                  <label htmlFor="moving">Mudanças / instalações</label>
                  <NumField
                    id="moving"
                    value={values.moving}
                    onChange={(v) => set("moving", v)}
                    max={10000}
                    step={50}
                  />
                </div>
              </div>
              <ul className="list" style={{ marginTop: "var(--s4)" }}>
                <li>
                  <span>Primeira renda + caução + adiantadas</span>
                  <b className="num">{euro(c.upRent)}</b>
                </li>
                <li>
                  <span>Móveis, equipamento e mudanças</span>
                  <b className="num">{euro(c.upOther)}</b>
                </li>
                <li className="emph">
                  <span>Total à entrada</span>
                  <b className="num gold">{euro(c.upfront)}</b>
                </li>
                <li>
                  <span>Meses de poupança para o juntar</span>
                  <b className="num">
                    {c.perMonth > 0 ? `${Math.ceil(c.upfront / c.perMonth)} meses` : "—"}
                  </b>
                </li>
              </ul>
            </div>
          </section>

          {/* 08 */}
          <section className="sec" id="s8">
            <div className="sechead">
              <div className="badge">08</div>
              <h2>Checklist</h2>
              <span className="tag">
                {done} / {CHECKS.length}
              </span>
            </div>
            <div className="secbody">
              <p className="hint">
                Confirmar antes de assinar — é aqui que o orçamento se decide.
              </p>
              <div className="chkbar">
                <div className="track">
                  <div className="fill" style={{ width: `${(done / CHECKS.length) * 100}%` }} />
                </div>
              </div>
              <div>
                {CHECKS.map((t, i) => (
                  <label className="check" key={t}>
                    <input
                      type="checkbox"
                      checked={checked[i] ?? false}
                      onChange={(e) =>
                        setChecked((prev) => prev.map((v, j) => (j === i ? e.target.checked : v)))
                      }
                    />
                    <span>{t}</span>
                  </label>
                ))}
              </div>
              <div className="note">
                Uma renda 300 € mais baixa representa <strong>3 600 € por ano</strong> — margem para
                imprevistos, férias e um eventual projeto de compra.
              </div>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}
