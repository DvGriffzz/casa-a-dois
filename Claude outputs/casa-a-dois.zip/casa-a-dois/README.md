# Casa a Dois 🏡

Simulador do custo de viver a dois em Aveiro — rendimentos, despesas por categoria, orçamento mensal, divisão justa dos custos, poupança anual, comparação de rendas, custo de entrada e checklist.

Next.js 15 (App Router) + React 19 + TypeScript. Página 100% estática, sem backend: tudo corre no browser e os valores ficam guardados em `localStorage`.

## Correr localmente

```bash
npm install
npm run dev
```

Abre http://localhost:3000

## Publicar na Vercel

**Opção A — via GitHub (recomendado, dá deploy automático a cada push)**

```bash
git init
git add -A
git commit -m "Casa a Dois — simulador"
git branch -M main
git remote add origin git@github.com:UTILIZADOR/casa-a-dois.git
git push -u origin main
```

Depois em [vercel.com/new](https://vercel.com/new): *Import Git Repository* → escolhe o repo → **Deploy**. A Vercel deteta o Next.js sozinha; não é preciso configurar nada.

**Opção B — direto da pasta, sem GitHub**

```bash
npx vercel          # preview
npx vercel --prod   # produção
```

Domínio: em *Project → Settings → Domains* podes mudar para algo como `casa-a-dois.vercel.app`.

## Estrutura

```
app/
  layout.tsx        metadata, fontes, CSS global
  page.tsx          hero + footer (server component)
  globals.css       todo o design system (variáveis CSS, dark mode, print)
components/
  Simulator.tsx     estado, cálculos e as 8 secções (client component)
  NumField.tsx      input numérico controlado, tolerante a edição
lib/
  model.ts          categorias, checklist, valores por defeito e a função `compute`
```

Toda a matemática vive em `lib/model.ts` → `compute(values, mode)`, uma função pura. Para mudar categorias de despesa, valores iniciais ou perguntas da checklist, é o único ficheiro a tocar.

## Notas

- Valores iniciais são ilustrativos, não cotações reais.
- Não inclui inflação, juros, alterações fiscais nem seguros de saúde.
- Os dados nunca saem do browser — não há base de dados nem analytics.
