export type ExpenseItem = { id: string; label: string; value: number };
export type ExpenseGroup = { id: string; name: string; color: string; items: ExpenseItem[] };

export const GROUPS: ExpenseGroup[] = [
  {
    id: "casa",
    name: "Casa",
    color: "#a99bff",
    items: [
      { id: "condominio", label: "Condomínio", value: 0 },
      { id: "luzgas", label: "Eletricidade e gás", value: 85 },
      { id: "agua", label: "Água", value: 20 },
      { id: "internet", label: "Internet", value: 35 },
      { id: "segurocasa", label: "Seguro de casa", value: 10 },
    ],
  },
  {
    id: "dia",
    name: "Dia-a-dia",
    color: "#6e9fd8",
    items: [
      { id: "super", label: "Supermercado (2 pessoas)", value: 400 },
      { id: "higiene", label: "Higiene e cuidados", value: 35 },
      { id: "prodcasa", label: "Produtos de casa", value: 25 },
      { id: "fora", label: "Restaurantes e take-away", value: 180 },
    ],
  },
  {
    id: "mob",
    name: "Mobilidade",
    color: "#5fb4c9",
    items: [
      { id: "combustivel", label: "Combustível", value: 140 },
      { id: "transportes", label: "Transportes públicos", value: 20 },
      { id: "auto", label: "Seguro e manutenção auto", value: 35 },
    ],
  },
  {
    id: "pess",
    name: "Pessoal e lazer",
    color: "#d59be0",
    items: [
      { id: "telemovel", label: "Telemóveis", value: 20 },
      { id: "saude", label: "Saúde e farmácia", value: 25 },
      { id: "lazer", label: "Lazer e subscrições", value: 80 },
      { id: "roupa", label: "Roupa e calçado", value: 30 },
    ],
  },
  {
    id: "res",
    name: "Reservas",
    color: "#ffc879",
    items: [
      { id: "imprevistos", label: "Imprevistos", value: 100 },
      { id: "outros", label: "Outros", value: 30 },
    ],
  },
];

export const CHECKS = [
  "O subsídio de alimentação está incluído nos líquidos?",
  "Quantos carros usamos e quantos km fazemos por mês?",
  "A casa está mobilada ou temos de equipar?",
  "Há empréstimos, créditos ou prestações a contar?",
  "Água quente: gás ou eletricidade?",
  "O condomínio está incluído na renda?",
  "Quem é responsável por obras e avarias?",
  "O contrato tem duração mínima ou fidelização?",
];

export const SECTIONS = [
  { id: "s1", n: "01", label: "Rendimentos" },
  { id: "s2", n: "02", label: "Despesas mensais" },
  { id: "s3", n: "03", label: "Orçamento do mês" },
  { id: "s4", n: "04", label: "Divisão dos custos" },
  { id: "s5", n: "05", label: "Poupança anual" },
  { id: "s6", n: "06", label: "Comparar rendas" },
  { id: "s7", n: "07", label: "Custo de entrada" },
  { id: "s8", n: "08", label: "Checklist" },
];

export type Values = {
  mine: number;
  mineN: number;
  hers: number;
  hersN: number;
  rent: number;
  goal: number;
  depositN: number;
  advanceN: number;
  furniture: number;
  moving: number;
  expenses: Record<string, number>;
};

export type Mode = "proportional" | "equal";

export const DEFAULTS: Values = {
  mine: 1300,
  mineN: 14,
  hers: 1600,
  hersN: 12,
  rent: 800,
  goal: 10000,
  depositN: 1,
  advanceN: 0,
  furniture: 1000,
  moving: 200,
  expenses: Object.fromEntries(
    GROUPS.flatMap((g) => g.items.map((i) => [i.id, i.value] as const))
  ),
};

export const RENT_COLOR = "#7f72d6";
export const LEFT_COLOR = "#5dd6ac";

export const euro = (x: number) =>
  new Intl.NumberFormat("pt-PT", {
    style: "currency",
    currency: "EUR",
    maximumFractionDigits: 0,
  }).format(Math.round(x || 0));

export const pct = (x: number) =>
  new Intl.NumberFormat("pt-PT", { style: "percent", maximumFractionDigits: 1 }).format(x || 0);

export const clamp = (v: number, a: number, b: number) => Math.min(b, Math.max(a, v));

export type Computed = ReturnType<typeof compute>;

export function compute(v: Values, mode: Mode) {
  const income = v.mine + v.hers;

  const groupSums: Record<string, number> = {};
  let other = 0;
  for (const g of GROUPS) {
    const s = g.items.reduce((a, i) => a + (v.expenses[i.id] || 0), 0);
    groupSums[g.id] = s;
    other += s;
  }

  const total = other + v.rent;
  const left = income - total;
  const yearIncome = v.mine * v.mineN + v.hers * v.hersN;
  const annual = yearIncome - total * 12;
  const rate = income > 0 ? left / income : 0;
  const rentShare = income > 0 ? v.rent / income : 0;
  const perMonth = annual / 12;

  const part = mode === "equal" ? 0.5 : income > 0 ? v.mine / income : 0.5;
  const mineShare = total * part;
  const herShare = total - mineShare;

  const upRent = v.rent * (1 + v.depositN + v.advanceN);
  const upOther = v.furniture + v.moving;
  const upfront = upRent + upOther;

  const rentsBase = [600, 700, 800, 900, 1000, 1100];
  const rents = rentsBase.includes(v.rent) ? [...rentsBase] : [...rentsBase, v.rent];
  rents.sort((a, b) => a - b);
  const scenarios = rents.map((r) => ({
    rent: r,
    left: income - other - r,
    annual: yearIncome - (other + r) * 12,
    share: income > 0 ? r / income : 0,
    current: r === v.rent,
  }));

  const health =
    left < 0
      ? { label: "Orçamento negativo", color: "var(--red)" }
      : left < 300
        ? { label: "Pouca margem", color: "var(--gold)" }
        : left < 600
          ? { label: "Margem moderada", color: "var(--gold)" }
          : { label: "Equilibrado", color: "var(--green)" };

  return {
    income, groupSums, other, total, left, yearIncome, annual, rate, rentShare,
    perMonth, mineShare, herShare, upRent, upOther, upfront, scenarios, health,
  };
}
