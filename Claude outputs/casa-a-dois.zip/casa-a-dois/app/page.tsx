import Simulator from "@/components/Simulator";

export default function Page() {
  return (
    <>
      <header className="hero">
        <div className="eyebrow">O nosso futuro · Aveiro</div>
        <h1>
          Casa a dois <span className="green">🏡</span>
        </h1>
        <p>
          Quanto custa arrendar um T1 em Aveiro e viver em conjunto? Tudo organizado em oito
          secções: <strong>rendimentos, despesas por categoria, orçamento, divisão justa,
          poupança, custo de entrada e checklist</strong>. Os valores são estimativas — ajustem-nos
          à vossa realidade.
        </p>
      </header>

      <Simulator />

      <footer className="footer">
        <strong>Casa a Dois — Aveiro.</strong> Simulador offline, em português de Portugal. Valores
        iniciais ilustrativos (não representam preços garantidos nem propostas de arrendamento).
        Não inclui inflação, alterações fiscais, juros, seguros de saúde nem despesas não
        introduzidas. Os valores ficam guardados apenas neste navegador e não são enviados para
        nenhum servidor.
      </footer>
    </>
  );
}
